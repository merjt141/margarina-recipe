interface Window {
    cwcAbrir: any;

}

declare var WebCC : any;